import 'package:flutter/material.dart';

class ButtonSection extends StatelessWidget{

  const ButtonSection({super.key})

  @override
  Widget build(BuildContext context) {
    
     final Color color Theme.of(context).primaryColor;
  }

}

class ButtonWithText extends StatelessWidget{

  const ButtonWithText({
    super.key,
    required this.color,
    required this.icon,
    required this.label,

  });

  final Color color;
  final Icon icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    
    return Column(
      mainAxisSize: MainAxisSize.min,
    )

  }

}